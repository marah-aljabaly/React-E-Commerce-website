
  
  export default function MainFooter() {
    return (
      <footer className="bg-dark text-white text-center py-3">
        <p>All Rights Reserved to Marah Aljabaly &copy; 2024</p>
      </footer>
    )
  }
  